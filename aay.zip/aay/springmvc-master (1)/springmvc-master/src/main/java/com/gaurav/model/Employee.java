package com.gaurav.model;

public class Employee {

	private int empid;
	private String role;
	private String name;
	private String dob;
	private int age;
	
	public int getEmpid()
	{
		return empid;
	}
	public void setEmpid(int empid)
	{
		this.empid=empid;
	}
	public String getRole()
	{
		return role;
	}
	public void setRole(String role)
	{
		this.role=role;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public String getDob()
	{
		return dob;
	}
	public void setDob(String dob)
	{
		this.dob=dob;
	}
	public int getAge()
	{
		return age;
	}
	public void setAge(int age)
	{
		this.age=age;
	}
}
