package com.gaurav.dao;

public interface Admindao {
	

}
