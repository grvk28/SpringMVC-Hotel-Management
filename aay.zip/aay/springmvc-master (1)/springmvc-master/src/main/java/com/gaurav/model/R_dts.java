package com.gaurav.model;

public class R_dts {
      private int roomno;
      private String iname;
      private String condn;
      private int nos;
	public int getRoomno() {
		return roomno;
	}
	public void setRoomno(int roomno) {
		this.roomno = roomno;
	}
	public String getIname() {
		return iname;
	}
	public void setIname(String iname) {
		this.iname = iname;
	}
	public String getCondn() {
		return condn;
	}
	public void setCondn(String condn) {
		this.condn = condn;
	}
	public int getNos() {
		return nos;
	}
	public void setNos(int nos) {
		this.nos = nos;
	}
}
