package com.gaurav;

public @interface Autowire {

}
