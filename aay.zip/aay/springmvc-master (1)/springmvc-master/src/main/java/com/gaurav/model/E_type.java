package com.gaurav.model;

public class E_type {
	private String role;
	private int prereq;
	private float salary;
	private int exp;
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public int getPrereq() {
		return prereq;
	}
	public void setPrereq(int prereq) {
		this.prereq = prereq;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public int getExp() {
		return exp;
	}
	public void setExp(int exp) {
		this.exp = exp;
	}
}
