package com.gaurav.model;

public class T_price {
	private int price;
	private String type;
	private int availabe;
	private String date;
	
	public int getPrice()
	{
		return price;
	}
	public void setPrice(int price)
	{
		this.price=price;
	}
	public String getType()
	{
		return type;
	}
	public void setType(String type )
	{
		this.type=type;
	}
	public int getAvailable()
	{
		return availabe;
	}
	public void setAvailable(int availabe)
	{
		this.availabe=availabe;
	}
	public String getDate()
	{
		return date;
	}
	public void setDate(String date)
	{
		this.date=date;
	}
}
