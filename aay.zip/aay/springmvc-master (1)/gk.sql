-- MySQL dump 10.13  Distrib 5.7.27, for Linux (x86_64)
--
-- Host: localhost    Database: db1
-- ------------------------------------------------------
-- Server version	5.7.27-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Ccart`
--

DROP TABLE IF EXISTS `Ccart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Ccart` (
  `uid` varchar(12) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `nos` int(11) DEFAULT '0',
  `tprice` float DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Ccart`
--

LOCK TABLES `Ccart` WRITE;
/*!40000 ALTER TABLE `Ccart` DISABLE KEYS */;
/*!40000 ALTER TABLE `Ccart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Customer`
--

DROP TABLE IF EXISTS `Customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Customer` (
  `bid` int(11) NOT NULL AUTO_INCREMENT,
  `cdate` date DEFAULT NULL,
  `odate` date DEFAULT NULL,
  `guests` int(11) DEFAULT NULL,
  `rooms` int(11) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Customer`
--

LOCK TABLES `Customer` WRITE;
/*!40000 ALTER TABLE `Customer` DISABLE KEYS */;
INSERT INTO `Customer` VALUES (14,'2019-10-16','2019-10-16',1,1,1,'grv'),(15,'2019-10-16','2019-10-16',1,1,1,'grv'),(16,'2019-10-16','2019-10-16',1,1,1,'grv'),(17,'2019-10-16','2019-10-16',1,1,1,'grv'),(18,'2019-10-16','2019-10-16',1,1,2,'grv'),(19,'2019-10-16','2019-10-16',1,1,2,'grv'),(20,'2019-10-24','2019-10-29',1,1,2,'grv'),(21,'2019-10-16','2019-10-23',1,1,1,'grv'),(22,'2019-10-16','2019-10-23',1,1,1,'grv'),(23,'2019-10-02','2019-10-17',1,1,1,'grv'),(24,'2019-10-16','2019-10-17',1,2,1,'grv'),(25,'2019-10-16','2019-10-17',1,2,1,'grv'),(26,'2019-10-16','2019-10-17',1,2,1,'grv'),(27,'2019-10-16','2019-10-17',1,2,2,'grv'),(28,'2019-10-16','2019-10-17',1,2,2,'grv'),(29,'2019-10-16','2019-10-17',1,2,1,'grv'),(30,'2019-10-23','2019-10-30',1,2,2,'grv'),(31,'2019-10-16','2019-10-16',1,1,1,'grv'),(32,'2019-10-16','2019-10-23',1,1,1,'grv'),(33,'2019-10-16','2019-10-17',1,1,1,'grv'),(34,'2019-10-16','2019-10-22',1,1,1,'grv'),(35,'2019-10-16','2019-10-22',1,1,1,'grv'),(36,'2019-10-16','2019-10-22',1,1,1,'grv'),(37,'2019-10-16','2019-10-17',1,1,1,'grv'),(38,'2019-10-16','2019-10-17',1,1,1,'grv'),(39,'2019-10-15','2019-10-16',1,1,1,'grv'),(40,'2019-10-17','2019-10-17',1,1,1,'grv'),(41,'2019-10-17','2019-10-17',1,1,1,'grv'),(42,'2019-10-17','2019-10-17',1,1,1,'grv'),(43,'2019-10-17','2019-10-17',1,1,1,'grv'),(44,'2019-10-17','2019-10-17',1,1,1,'grv'),(45,'2019-10-17','2019-10-17',1,1,1,'grv'),(46,'2019-10-24','2019-10-23',1,2,1,'grv'),(47,'2019-10-24','2019-10-23',1,2,1,'grv'),(48,'2019-10-24','2019-10-23',1,2,1,'grv'),(49,'2019-10-17','2019-10-18',1,1,1,'grv'),(50,'2019-10-17','2019-10-24',1,1,1,'grv'),(51,'2019-10-17','2019-10-22',1,1,1,'grv'),(52,'2019-10-17','2019-10-22',1,1,1,'grv'),(53,'2019-10-16','2019-10-24',1,1,1,'grv'),(54,'2019-10-16','2019-10-18',1,1,1,'grv'),(55,'2019-10-17','2019-10-24',1,1,1,'grv'),(56,'2019-10-16','2019-10-18',1,1,1,'grv'),(57,'2019-10-16','2019-10-19',1,1,1,'grv'),(58,'2019-10-16','2019-10-17',1,1,1,'grv'),(59,'2019-10-17','2019-10-24',5,1,2,'grv'),(60,'2019-10-17','2019-10-24',5,1,2,'grv'),(61,'2019-10-17','2019-10-24',5,1,2,'grv'),(62,'2019-10-17','2019-10-24',5,1,2,'grv'),(63,'2019-10-17','2019-10-24',5,1,2,'grv'),(64,'2019-10-17','2019-10-23',1,1,1,'grv'),(65,'2019-10-31','2019-11-07',11,3,2,'grv'),(66,'2019-10-18','2019-10-19',2,3,3,'grv'),(67,'2019-10-18','2019-10-19',2,1,3,'grv'),(68,'2019-10-18','2019-10-25',4,1,3,'grv'),(69,'2019-10-31','2019-11-01',3,1,3,'grv'),(70,'2019-10-24','2019-10-25',7,6,1,'grv'),(71,'2019-10-18','2019-10-25',100,4,1,'grv'),(72,'2019-10-18','2019-10-19',3,1,1,'grv'),(73,'2019-10-18','2019-10-20',1,1,1,'grv'),(74,'2019-10-17','2019-10-18',2,1,1,'grv'),(75,'2019-10-18','2019-10-19',3,1,2,'grv'),(76,'2019-10-17','2019-10-18',2,1,2,'grv'),(77,'2019-10-18','2019-10-19',2,2,2,'grv'),(78,'2019-10-25','2019-10-26',1,2,2,'grv'),(79,'2019-10-18','2019-10-19',1,2,1,'grv');
/*!40000 ALTER TABLE `Customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `R_type`
--

DROP TABLE IF EXISTS `R_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `R_type` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(22) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `feat` varchar(12) DEFAULT NULL,
  `nos` int(11) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `R_type`
--

LOCK TABLES `R_type` WRITE;
/*!40000 ALTER TABLE `R_type` DISABLE KEYS */;
INSERT INTO `R_type` VALUES (1,'Single',1230,'AC',50),(2,'Single',830,'Non AC',50),(3,'Double',4230,'Non AC',50);
/*!40000 ALTER TABLE `R_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Room`
--

DROP TABLE IF EXISTS `Room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Room` (
  `cid` int(11) DEFAULT NULL,
  `rno` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Room`
--

LOCK TABLES `Room` WRITE;
/*!40000 ALTER TABLE `Room` DISABLE KEYS */;
INSERT INTO `Room` VALUES (1,101),(1,102),(1,103),(1,104),(1,105),(1,106),(2,107),(2,108),(2,201),(2,202),(2,203),(2,204),(2,205),(2,206),(3,207);
/*!40000 ALTER TABLE `Room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `T_price`
--

DROP TABLE IF EXISTS `T_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `T_price` (
  `date` date DEFAULT NULL,
  `type` varchar(12) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `avail` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `T_price`
--

LOCK TABLES `T_price` WRITE;
/*!40000 ALTER TABLE `T_price` DISABLE KEYS */;
/*!40000 ALTER TABLE `T_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bill`
--

DROP TABLE IF EXISTS `bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bill` (
  `date` date DEFAULT NULL,
  `Reserv_id` varchar(12) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `amount` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill`
--

LOCK TABLES `bill` WRITE;
/*!40000 ALTER TABLE `bill` DISABLE KEYS */;
INSERT INTO `bill` VALUES ('2009-08-14','123','qwerty',1,1234);
/*!40000 ALTER TABLE `bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booked_location`
--

DROP TABLE IF EXISTS `booked_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booked_location` (
  `lid` int(11) DEFAULT NULL,
  `bdate` date DEFAULT NULL,
  `event` varchar(20) DEFAULT NULL,
  `uid` varchar(25) DEFAULT NULL,
  `bid` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`bid`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booked_location`
--

LOCK TABLES `booked_location` WRITE;
/*!40000 ALTER TABLE `booked_location` DISABLE KEYS */;
INSERT INTO `booked_location` VALUES (1,'2018-10-09','Official Meet','ayushi',5),(1,'2018-10-09','Celebration Party','ayushi',6),(1,'2018-10-09','Celebration Party','auhan',7),(1,'2018-10-09','Birthday','auhan',8),(1,'2018-10-09','Official Meet','auhan',9),(1,'2018-10-09','Official Meet','auhan',10),(1,'2018-10-09','Wedding','auhan',11),(1,'2018-10-09','Celebration Party','ayushi',12),(1,'2018-10-21','Celebration Party','ayushi',13),(1,'2018-10-28','Birthday','auhan',14),(1,'2018-10-28','Birthday','auhan',15),(1,'2018-10-11','Celebration Party','auhan',16),(1,'2018-10-12','Celebration Party','auhan',17),(1,'2019-10-11','Birthday','aa',18),(1,'2019-10-15','Wedding','aa',19),(2,'2019-10-15','Birthday','aa',20),(1,'2019-10-14','Birthday','grv',21),(1,'2019-10-30','Official Meet','grv',22),(1,'2019-10-17','Official Meet','grv',23);
/*!40000 ALTER TABLE `booked_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cart` (
  `uid` varchar(20) DEFAULT NULL,
  `iid` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT '1',
  `tprice` float DEFAULT '0',
  KEY `fk` (`iid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart`
--

LOCK TABLES `cart` WRITE;
/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
INSERT INTO `cart` VALUES ('aa',2,1,100);
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `cname` varchar(20) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Recommended'),(2,'Starters & Appetiser'),(3,'Indian'),(4,'Main Course'),(5,'Starters'),(6,'Assorted Breads'),(7,'Dal'),(8,'Fish & Chicken'),(9,'Rice & Biryani'),(10,'Salad'),(11,'Desserts'),(12,'Beverages'),(13,'Breads');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_address`
--

DROP TABLE IF EXISTS `e_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `e_address` (
  `empid` varchar(12) DEFAULT NULL,
  `pin` int(11) DEFAULT NULL,
  `fname` varchar(15) DEFAULT NULL,
  `locality` varchar(15) DEFAULT NULL,
  `landmark` varchar(15) DEFAULT NULL,
  `city` varchar(15) DEFAULT NULL,
  `state` varchar(15) DEFAULT NULL,
  `details` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_address`
--

LOCK TABLES `e_address` WRITE;
/*!40000 ALTER TABLE `e_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `e_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_email`
--

DROP TABLE IF EXISTS `e_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `e_email` (
  `empid` varchar(14) DEFAULT NULL,
  `email` varchar(24) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_email`
--

LOCK TABLES `e_email` WRITE;
/*!40000 ALTER TABLE `e_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `e_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_mobiles`
--

DROP TABLE IF EXISTS `e_mobiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `e_mobiles` (
  `empid` varchar(12) DEFAULT NULL,
  `mobile` varchar(14) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_mobiles`
--

LOCK TABLES `e_mobiles` WRITE;
/*!40000 ALTER TABLE `e_mobiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `e_mobiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_preq`
--

DROP TABLE IF EXISTS `e_preq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `e_preq` (
  `role` varchar(12) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `courses` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_preq`
--

LOCK TABLES `e_preq` WRITE;
/*!40000 ALTER TABLE `e_preq` DISABLE KEYS */;
/*!40000 ALTER TABLE `e_preq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_type`
--

DROP TABLE IF EXISTS `e_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `e_type` (
  `role` varchar(12) DEFAULT NULL,
  `prereq` int(11) DEFAULT NULL,
  `salary` float DEFAULT NULL,
  `exp` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_type`
--

LOCK TABLES `e_type` WRITE;
/*!40000 ALTER TABLE `e_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `e_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee` (
  `role` varchar(12) DEFAULT NULL,
  `name` varchar(15) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `empid` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`empid`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES ('asdfg','qwerty','2019-09-23',20,9),('asdfg','qwerty','2019-09-23',20,10),('asdfghj','qwertyu','2009-12-08',40,12);
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `event` varchar(20) NOT NULL,
  PRIMARY KEY (`event`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES ('Birthday'),('Celebration Party'),('Normal'),('Official Meet'),('Ring Ceremony'),('Wedding'),('Wedding Anniversary');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice`
--

DROP TABLE IF EXISTS `invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice` (
  `cid` int(11) DEFAULT NULL,
  `pmode` varchar(12) DEFAULT NULL,
  `descrip` varchar(30) DEFAULT NULL,
  `pid` varchar(18) DEFAULT NULL,
  `pstatus` varchar(8) DEFAULT NULL,
  `total` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice`
--

LOCK TABLES `invoice` WRITE;
/*!40000 ALTER TABLE `invoice` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items` (
  `iid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `price` float DEFAULT NULL,
  PRIMARY KEY (`iid`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (1,'Pizza Chicken Tikka',2,113),(2,'Veggie Supreme',2,100),(3,'Pizza Paneer',2,100),(11,'Plastic Folding Chair',1,3.5);
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location` (
  `lid` int(11) NOT NULL AUTO_INCREMENT,
  `lname` varchar(45) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `del_price` int(11) DEFAULT NULL,
  PRIMARY KEY (`lid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES (1,'Nandan Hotel','Brahampura, Muzaffarpur,Bihar',20),(2,'Nandan Hotel','Srisiya Buzurg, Muzaffarpur,Bihar',120);
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_items` (
  `cid` int(11) DEFAULT NULL,
  `iid` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `tprice` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
INSERT INTO `order_items` VALUES (23,11,100,350),(24,14,20,800),(24,13,50,600),(24,27,5,2850),(25,28,5,60),(25,11,100,350),(25,20,7,84),(25,14,50,2000),(25,16,1,480),(28,23,1,135),(30,11,100,350),(24,24,25,3375),(34,14,1,40),(35,20,1,12),(35,11,1,0),(35,11,1,3.5),(35,2,1,100),(35,2,1,100),(41,2,1,100),(41,1,1,113),(41,2,1,100),(41,1,1,113),(41,2,1,100),(41,3,1,100),(41,1,1,0),(41,1,8,904),(46,1,1,113),(46,1,1,0),(46,2,1,0),(46,1,1,0),(46,2,1,0),(41,1,1,113);
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `bid` int(11) DEFAULT NULL,
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (18,35,'aa'),(18,36,'aa'),(18,37,'aa'),(18,38,'aa'),(18,39,'aa'),(18,40,'aa'),(21,41,'grv'),(21,42,'grv'),(21,43,'grv'),(21,44,'grv'),(21,45,'grv'),(22,46,'grv'),(21,47,'grv'),(21,48,'grv'),(21,49,'grv'),(21,50,'grv'),(21,51,'grv'),(21,52,'grv'),(22,53,'grv'),(22,54,'grv'),(22,55,'grv'),(22,56,'grv'),(22,57,'grv'),(22,58,'grv'),(22,59,'grv'),(21,60,'grv');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `placed_order`
--

DROP TABLE IF EXISTS `placed_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `placed_order` (
  `bid` int(11) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `iid` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `tprice` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `placed_order`
--

LOCK TABLES `placed_order` WRITE;
/*!40000 ALTER TABLE `placed_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `placed_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `r_dts`
--

DROP TABLE IF EXISTS `r_dts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `r_dts` (
  `roomno` int(11) DEFAULT NULL,
  `iname` varchar(12) DEFAULT NULL,
  `nos` int(11) DEFAULT NULL,
  `condn` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `r_dts`
--

LOCK TABLES `r_dts` WRITE;
/*!40000 ALTER TABLE `r_dts` DISABLE KEYS */;
/*!40000 ALTER TABLE `r_dts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `r_type`
--

DROP TABLE IF EXISTS `r_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `r_type` (
  `type` varchar(12) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `feat` varchar(12) DEFAULT NULL,
  `nos` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `r_type`
--

LOCK TABLES `r_type` WRITE;
/*!40000 ALTER TABLE `r_type` DISABLE KEYS */;
INSERT INTO `r_type` VALUES ('single',1200,'Non AC',12),('single',3200,'AC',5),('double',5000,'AC',4),('double',2000,'Non AC',14),('hall',12000,'Non AC',2),('hall',12000,'AC',2);
/*!40000 ALTER TABLE `r_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `review` (
  `cid` int(11) DEFAULT NULL,
  `roomno` int(11) DEFAULT NULL,
  `category` varchar(15) DEFAULT NULL,
  `Reserv_id` varchar(14) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL,
  `details` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rmdts`
--

DROP TABLE IF EXISTS `rmdts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rmdts` (
  `roomno` int(11) NOT NULL,
  `item_name` varchar(15) DEFAULT NULL,
  `nos` int(11) DEFAULT NULL,
  `condtn` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`roomno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rmdts`
--

LOCK TABLES `rmdts` WRITE;
/*!40000 ALTER TABLE `rmdts` DISABLE KEYS */;
/*!40000 ALTER TABLE `rmdts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock`
--

DROP TABLE IF EXISTS `stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock` (
  `prdate` date DEFAULT NULL,
  `condn` varchar(10) DEFAULT NULL,
  `proname` varchar(30) NOT NULL,
  `ven_id` int(11) DEFAULT NULL,
  `pro_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quantity` int(11) NOT NULL,
  `price` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock`
--

LOCK TABLES `stock` WRITE;
/*!40000 ALTER TABLE `stock` DISABLE KEYS */;
INSERT INTO `stock` VALUES ('2019-10-10','Good','Table',1,1,2,7,1000);
/*!40000 ALTER TABLE `stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supply`
--

DROP TABLE IF EXISTS `supply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supply` (
  `cid` int(11) DEFAULT NULL,
  `sid` int(11) DEFAULT NULL,
  `iid` int(11) DEFAULT NULL,
  `rate` float DEFAULT NULL,
  `nos` int(11) DEFAULT NULL,
  `mobile` varchar(14) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supply`
--

LOCK TABLES `supply` WRITE;
/*!40000 ALTER TABLE `supply` DISABLE KEYS */;
/*!40000 ALTER TABLE `supply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supply_dts`
--

DROP TABLE IF EXISTS `supply_dts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supply_dts` (
  `sid` int(11) DEFAULT NULL,
  `name` varchar(12) DEFAULT NULL,
  `mobile` varchar(14) DEFAULT NULL,
  `address` varchar(40) DEFAULT NULL,
  `details` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supply_dts`
--

LOCK TABLES `supply_dts` WRITE;
/*!40000 ALTER TABLE `supply_dts` DISABLE KEYS */;
/*!40000 ALTER TABLE `supply_dts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_price`
--

DROP TABLE IF EXISTS `t_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_price` (
  `price` int(11) DEFAULT NULL,
  `type` varchar(12) DEFAULT NULL,
  `avail` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_price`
--

LOCK TABLES `t_price` WRITE;
/*!40000 ALTER TABLE `t_price` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  `enabled` int(11) DEFAULT '1',
  `name` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `phone` varchar(13) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('aa','123',1,'aaa','aaa','111'),('aaa','aaa',1,'aaa','aaa','111'),('auhan','asdf',1,'Auhan','auhan@gmail.com','123456789'),('Gaurav','aaa',1,'aaa','aaa','111'),('gk','123',1,'gaurav kumar','gk@gmail.com','1234567'),('grv','123',1,'aaa','aaa','111'),('qwe','111',1,'aaa','aaa','111'),('qwerty','123456',1,'ADMIN','admin@gmail.com','9999999999'),('tora','tora',1,'Tora','tora@gmail.com','0987654321');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_roles`
--

DROP TABLE IF EXISTS `users_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_roles` (
  `user` varchar(20) NOT NULL,
  `role` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_roles`
--

LOCK TABLES `users_roles` WRITE;
/*!40000 ALTER TABLE `users_roles` DISABLE KEYS */;
INSERT INTO `users_roles` VALUES ('aa','ROLE_USER'),('aaa','ROLE_USER'),('auhan','ROLE_USER'),('ayushi','ROLE_USER'),('Gaurav','ROLE_USER'),('grv','ROLE_USER'),('qwe','ROLE_USER'),('qwerty','ROLE_ADMIN'),('tora','ROLE_USER');
/*!40000 ALTER TABLE `users_roles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-17 13:19:04
